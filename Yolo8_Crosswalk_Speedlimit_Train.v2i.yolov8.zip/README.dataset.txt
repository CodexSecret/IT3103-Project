# Yolo8_Crosswalk_Speedlimit_Train > 2025-01-02 4:45pm
https://universe.roboflow.com/eshton-yang-wddun/yolo8_crosswalk_speedlimit_train

Provided by a Roboflow user
License: CC BY 4.0

